//
//  EmployeeRoster221099261Tests.swift
//  EmployeeRoster221099261Tests
//
//  Created by student-2 on 25/11/24.
//

import Testing
@testable import EmployeeRoster221099261

struct EmployeeRoster221099261Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
