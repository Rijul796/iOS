//
//  EmployeeRoster2210992152Tests.swift
//  EmployeeRoster2210992152Tests
//
//  Created by student-2 on 25/11/24.
//

import Testing
@testable import EmployeeRoster2210992152

struct EmployeeRoster2210992152Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
